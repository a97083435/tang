<?php
require_once __DIR__ . '/lib/spider.php';

class 河马短剧 extends BaseSpider {
    private $apiUrl = "https://freevideo.zqqds.cn";
    private $cateManual = [
        "精选" => "53@精选",
        "古装" => "54@古装",
        "重生" => "55@重生",
        "家庭" => "56@家庭",
        "恋爱" => "57@恋爱"
    ];
    private $key = "ZHpramdmeXhnc2h5bGd6bQ==";
    private $iv = "YXBpdXBkb3duZWRjcnlwdA==";
    private $UA = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36";

    protected function getHeaders() {
        return [
            'User-Agent: ' . $this->UA,
            'Referer: ' . $this->apiUrl
        ];
    }

    private function aesEncrypt($text) {
        try {
            $key = base64_decode($this->key);
            $iv = base64_decode($this->iv);
            $encrypted = openssl_encrypt($text, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);
            return base64_encode($encrypted);
        } catch (Exception $e) {
            return "";
        }
    }

    private function aesDecrypt($encryptedData) {
        try {
            $key = base64_decode($this->key);
            $iv = base64_decode($this->iv);
            $decrypted = openssl_decrypt(base64_decode($encryptedData), 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $iv);
            return $decrypted;
        } catch (Exception $e) {
            return "{}";
        }
    }

    private function encryptPhoneInfo($text) {
        try {
            return base64_encode($text);
        } catch (Exception $e) {
            return $text;
        }
    }

    private function decryptPhoneInfo($encodedText) {
        try {
            return base64_decode($encodedText);
        } catch (Exception $e) {
            return $encodedText;
        }
    }

    private function encryptData() {
        $randomUuid = $this->generateUuid4();
        $brandEncrypted = $this->encryptPhoneInfo("vivo");
        $modelEncrypted = $this->encryptPhoneInfo("V1938T");
        $manuEncrypted = $this->encryptPhoneInfo("vivo");
        $osEncrypted = $this->encryptPhoneInfo("android");
        $data = [
            "version" => "2.1.0",
            "pname" => "com.dz.hmjc",
            "channelCode" => "HMJC1000002",
            "utdidTmp" => "A20250528195953036srZcvA",
            "token" => "",
            "utdid" => "d5d959973340bb1325b551cce488a191",
            "os" => "android",
            "osv" => 28,
            "brand" => "vivo",
            "model" => "V1938T",
            "manu" => "vivo",
            "userId" => "2484393607",
            "launch" => "shortcut",
            "mchid" => "HMJC1000002",
            "nchid" => "VHSE1000000",
            "session1" => $randomUuid,
            "session2" => $randomUuid,
            "startScene" => "shortcut",
            "recSwitch" => true,
            "installTime" => 1748433575024,
            "p" => 30
        ];
        $plaintext = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT);
        $encryptedB64 = $this->aesEncrypt($plaintext);
        return [
            "alg" => "HG45LKBS",
            "datas" => $encryptedB64,
            "content-type" => "application/json; charset=utf-8",
            "user-agent" => "okhttp/4.10.0"
        ];
    }

    private function generateUuid4() {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    private function fetchApiData($portal, $bodyText) {
        try {
            $encryptedBody = $this->aesEncrypt($bodyText);
            if (empty($encryptedBody)) {
                return null;
            }
            $headers = $this->encryptData();
            $curlHeaders = [];
            foreach ($headers as $key => $value) {
                $curlHeaders[] = "$key: $value";
            }
            $response = $this->fetch($this->apiUrl . "/free-video-portal/portal/{$portal}", [
                CURLOPT_POST => 1,
                CURLOPT_POSTFIELDS => $encryptedBody,
                CURLOPT_HTTPHEADER => $curlHeaders
            ], $this->getHeaders());
            if (!empty($response)) {
                $result = json_decode($response, true);
                if (isset($result['data'])) {
                    $decryptedData = $this->aesDecrypt($result['data']);
                    if (!empty($decryptedData)) {
                        return json_decode($decryptedData, true);
                    }
                }
            }
            return null;
        } catch (Exception $e) {
            return null;
        }
    }

    public function homeContent($filter) {
        $classes = [
            ["type_id" => "53@精选", "type_name" => "精选"],
            ["type_id" => "54@古装", "type_name" => "古装"],
            ["type_id" => "55@重生", "type_name" => "重生"],
            ["type_id" => "56@家庭", "type_name" => "家庭"],
            ["type_id" => "57@恋爱", "type_name" => "恋爱"]
        ];
        return ['class' => $classes, 'list' => []];
    }

    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $result = ['list' => [], 'page' => $pg, 'pagecount' => 9999, 'limit' => 90, 'total' => 999999];
        try {
            $fenge = explode("@", $tid);
            $cid = $fenge[0];
            $cname = isset($fenge[1]) ? $fenge[1] : "";
            $body = json_encode([
                "recSwitch" => true,
                "storePageId" => 10002,
                "channelGroupId" => "10",
                "channelId" => intval($cid),
                "channelName" => $cname,
                "lastColumnStyle" => 3,
                "fromColumnId" => "1",
                "pageFlag" => strval($pg),
                "theaterSubscriptSwitch" => true
            ], JSON_UNESCAPED_UNICODE);
            $apiData = $this->fetchApiData("1125", $body);
            if ($apiData && isset($apiData['columnData']) && !empty($apiData['columnData'])) {
                $videoData = $apiData['columnData'][0]['videoData'] ?? [];
                $videos = [];
                foreach ($videoData as $vod) {
                    $videos[] = [
                        "vod_id" => $vod['bookId'] ?? '',
                        "vod_name" => $vod['bookName'] ?? '',
                        "vod_pic" => $vod['coverWap'] ?? '',
                        "vod_remarks" => $vod['finishStatusCn'] ?? ''
                    ];
                }
                $result['list'] = $videos;
            }
        } catch (Exception $e) {
            // 忽略异常
        }
        return $result;
    }

    public function searchContent($key, $quick = false, $pg = 1) {
        $result = ['list' => [], 'page' => $pg, 'pagecount' => 9999, 'limit' => 90, 'total' => 999999];
        try {
            $body = json_encode([
                "keyword" => $key,
                "page" => intval($pg),
                "size" => 15,
                "searchSource" => "搜索按钮",
                "hotWordType" => 2,
                "tagIds" => "",
                "reservationSwitch" => true
            ], JSON_UNESCAPED_UNICODE);
            $apiData = $this->fetchApiData("1803", $body);
            if ($apiData && isset($apiData['searchVos'])) {
                $videos = [];
                foreach ($apiData['searchVos'] as $vod) {
                    $videos[] = [
                        "vod_id" => $vod['bookId'] ?? '',
                        "vod_name" => $vod['bookName'] ?? '',
                        "vod_pic" => $vod['coverWap'] ?? '',
                        "vod_remarks" => $vod['finishStatusCn'] ?? ''
                    ];
                }
                $result['list'] = $videos;
            }
        } catch (Exception $e) {
            // 忽略异常
        }
        return $result;
    }

    public function detailContent($ids) {
        $result = ['list' => []];
        if (empty($ids)) {
            return $result;
        }
        $bookId = is_array($ids) ? $ids[0] : $ids;
        try {
            $body = json_encode([
                "bookId" => $bookId,
                "needNextChapter" => 0,
                "isNeedAlias" => "",
                "bookAlias" => "",
                "resolutionRate" => "720P"
            ], JSON_UNESCAPED_UNICODE);
            $apiData = $this->fetchApiData("1131", $body);
            if (!$apiData || !isset($apiData['videoInfo'])) {
                return $result;
            }
            $videoInfo = $apiData['videoInfo'];
            $chapterList = $apiData['chapterList'] ?? [];
            $protagonist = $videoInfo['protagonist'] ?? [];
            $vodActor = !empty($protagonist) ? implode(', ', $protagonist) : "";
            $vodDirector = !empty($protagonist) ? $protagonist[0] : "";
            $bookTags = $videoInfo['bookTags'] ?? [];
            $bookTagsStr = !empty($bookTags) ? implode(', ', $bookTags) : "";
            $vodContent = $videoInfo['introduction'] ?? '';
            $vod = [
                "vod_id" => $bookId,
                "vod_name" => $videoInfo['bookName'] ?? '',
                "vod_pic" => $videoInfo['coverWap'] ?? '',
                "vod_remarks" => $videoInfo['finishStatusCn'] ?? "" . " " . $bookTagsStr,
                "vod_content" => $vodContent,
                "vod_actor" => $vodActor,
                "vod_director" => $vodDirector,
                "vod_year" => $videoInfo['utime'] ?? '',
                "vod_area" => "中国",
                "vod_play_from" => "河马短剧",
                "vod_play_url" => $this->buildPlayUrl($bookId, $chapterList)
            ];
            $result['list'] = [$vod];
        } catch (Exception $e) {
            // 忽略异常
        }
        return $result;
    }

    private function buildPlayUrl($bookId, $chapterList) {
        $episodes = [];
        if (empty($chapterList)) {
            return "";
        }
        // 按chapterNum排序
        usort($chapterList, function($a, $b) {
            return ($a['chapterNum'] ?? 0) <=> ($b['chapterNum'] ?? 0);
        });
        $lastChapterId = !empty($chapterList) ? $chapterList[count($chapterList) - 1]['chapterId'] ?? '' : '';
        foreach ($chapterList as $chapter) {
            $chapterId = $chapter['chapterId'] ?? '';
            $chapterName = $chapter['chapterName'] ?? '';
            if (!empty($chapterId)) {
                $episodeUrl = "{$bookId}@{$chapterId}@{$lastChapterId}";
                $episodes[] = $chapterName . '$' . $episodeUrl;
            }
        }
        return implode('#', $episodes);
    }

    public function playerContent($flag, $id, $vipFlags = []) {
        $result = [
            "parse" => 0,
            "url" => "",
            "header" => "",
            "playUrl" => ""
        ];
        try {
            $parts = explode('@', $id);
            if (count($parts) >= 2) {
                $bookId = $parts[0];
                $chapterId = $parts[1];
                $lastChapterId = count($parts) > 2 ? $parts[2] : $chapterId;
                $videoUrl = $this->getVideoUrlFromApi($bookId, $chapterId, $lastChapterId);
                if (!empty($videoUrl)) {
                    $result["url"] = $videoUrl;
                    $result["header"] = [
                        "User-Agent" => "MOBILE_UA",
                        "Referer" => $this->apiUrl
                    ];
                    return $result;
                }
            }
        } catch (Exception $e) {
            // 忽略异常
        }
        return $result;
    }

    private function getVideoUrlFromApi($bookId, $chapterId, $lastChapterId) {
        try {
            $body = json_encode([
                "bookId" => $bookId,
                "chapterIds" => [$chapterId],
                "unClockType" => "load",
                "chapterId" => $lastChapterId,
                "resolutionRate" => "720P"
            ], JSON_UNESCAPED_UNICODE);
            $apiData = $this->fetchApiData("1139", $body);
            if ($apiData && isset($apiData['chapterInfo']) && !empty($apiData['chapterInfo']) &&
                isset($apiData['chapterInfo'][0]['content']) &&
                isset($apiData['chapterInfo'][0]['content']['mp4SwitchUrl'])) {
                $mp4Urls = $apiData['chapterInfo'][0]['content']['mp4SwitchUrl'];
                if (!empty($mp4Urls)) {
                    return $mp4Urls[0];
                }
            }
            return null;
        } catch (Exception $e) {
            return null;
        }
    }
}

(new 河马短剧())->run();