<?php
require_once __DIR__ . '/lib/spider.php';

// ================= 核心配置类 =================
class KuwoConfig {
    public static function getRule() {
        return [
            '类型' => '听书',
            'title' => '酷我听书[听]',
            'host' => 'http://tingshu.kuwo.cn',
            'url' => '/v2/api/search/filter/albums?classifyId=fyfilter&notrace=0&source=kwplayer_ar_9.1.8.1_tvivo.apk&platform=1&kweexVersion=1.1.5&uid=2511482006&sortType=playCnt&loginUid=540339516&bksource=kwbook_ar_9.1.8.1_tvivo.apk&rn=21&categoryId=fyclass&pn=fypage',
            'searchUrl' => 'http://search.kuwo.cn/r.s?client=kt&all=**&ft=album&newsearch=1&itemset=web_2013&cluster=0&pn=(fypage-1)&rn=21&rformat=json&encoding=utf8&show_copyright_off=1&vipver=MUSIC_8.0.3.0_BCS75&show_series_listen=1&version=9.1.8.1',
            'searchable' => 2,
            'quickSearch' => 0,
            'filterable' => 1,
            'filter_url' => '{{fl.class or \'44\'}}',
            'class_name' => '有声小说&音乐&相声评书&影视原声',
            'class_url' => '2&37&5&62',
            'play_parse' => true,
            'double' => true
        ];
    }
}

class Spider extends BaseSpider {
    private $HOST;
    protected $headers;
    private $rule;
    
    public function init($extend = '') {
        $this->rule = KuwoConfig::getRule();
        $this->HOST = $this->rule['host'];
        $this->headers = ['User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'];
    }
    
    public function homeContent($filter) {
        $class_names = explode('&', $this->rule['class_name']);
        $class_urls = explode('&', $this->rule['class_url']);
        $classes = [];
        for ($i = 0; $i < count($class_names); $i++) {
            $classes[] = ['type_id' => $class_urls[$i], 'type_name' => $class_names[$i]];
        }
        return ['class' => $classes, 'filters' => []];
    }
    
    public function categoryContent($tid, $pg = 1, $filter = [], $extend = []) {
        $list = [];
        $limit = 40;
        $host = $this->HOST;
        $category_map = ['2' => '有声小说', '37' => '音乐', '5' => '相声评书', '62' => '影视原声'];
        $category_name = $category_map[$tid] ?? '';
        $keyword = urlencode($category_name);
        $page_start = ($pg - 1) * $limit;
        $base_params = '&notrace=0&source=kwplayer_ar_9.1.8.1_tvivo.apk&platform=1&kweexVersion=1.1.5&uid=2511482006&loginUid=540339516&bksource=kwbook_ar_9.1.8.1_tvivo.apk&rn=' . $limit;
        
        // API请求列表
        $api_urls = [
            $host . '/v2/api/search/filter/albums?classifyId=' . $tid . $base_params . '&pn=' . $pg,
            $host . '/v2/api/search/filter/albums?categoryId=' . $tid . $base_params . '&pn=' . $pg,
            $host . '/v2/api/search/albums?classifyId=' . $tid . $base_params . '&pn=' . $pg,
            $host . '/v2/api/search/filter/albums?classifyId=' . $tid . '&categoryId=' . $tid . $base_params . '&pn=' . $pg,
            'http://search.kuwo.cn/r.s?client=kt&all=' . $keyword . '&ft=album&newsearch=1&cluster=0&pn=' . $page_start . '&rn=' . $limit . '&rformat=json&encoding=utf8',
            $host . '/v2/api/search/filter/albums?rn=' . $limit . '&pn=' . $pg . '&sortType=playCnt',
            $host . '/v2/api/search/albums?rn=' . $limit . '&pn=' . $pg
        ];
        
        // 遍历API获取数据
        foreach ($api_urls as $url) {
            if (count($list) >= $limit) break;
            $resp = $this->fetch($url, [], $this->headers);
            
            // 处理JSON/JSONP响应
            $json = strpos($resp, 'callback(') === 0 ? json_decode(preg_replace('/^callback\((.*?)\)$/', '$1', $resp), true) : json_decode($resp, true);
            if ($json === null) continue;
            
            // 提取数据项
            $items = [];
            if (isset($json['data']['data']) && is_array($json['data']['data'])) $items = $json['data']['data'];
            elseif (isset($json['data']) && is_array($json['data'])) $items = $json['data'];
            elseif (isset($json['abslist'])) {
                $items = array_filter($json['abslist'], function($item) { return isset($item['name']) && (isset($item['DC_TARGETID']) || isset($item['id'])); });
            } elseif (isset($json['list']) && is_array($json['list'])) $items = $json['list'];
            elseif (is_array($json)) $items = $json;
            
            // 解析数据
            foreach ($items as $it) {
                $album_id = $it['albumId'] ?? $it['DC_TARGETID'] ?? $it['id'] ?? '';
                $album_name = $it['albumName'] ?? $it['name'] ?? $it['title'] ?? '';
                if (empty($album_id) || empty($album_name)) continue;
                
                $cover = $it['coverImg'] ?? $it['pic'] ?? $it['img'] ?? '';
                $desc = $it['title'] ?? $it['artist'] ?? $it['description'] ?? $it['singer'] ?? '';
                $detail_url = 'http://search.kuwo.cn/r.s?stype=albuminfo&user=8d378d72qw28f5f4&uid=2511552006&loginUid=540129516&loginSid=958467960&prod=kwplayer_ar_9.1.8.1&bkprod=kwbook_ar_9.1.8.1&source=kwplayer_ar_9.1.8.1_tvivo.apk&bksource=kwbook_ar_9.1.8.1_tvivo.apk&corp=kuwo&albumid=' . $album_id . '&pn=0&rn=5000&show_copyright_off=1&vipver=MUSIC_8.2.0.0_BCS17&mobi=1&iskwbook=1';
                
                $list[] = ['vod_id' => $detail_url, 'vod_name' => $album_name, 'vod_pic' => $cover, 'vod_remarks' => $desc];
                if (count($list) >= $limit) break;
            }
        }
        
        // 默认数据
        if (empty($list)) {
            $list[] = [
                'vod_id' => 'http://search.kuwo.cn/r.s?stype=albuminfo&albumid=12345',
                'vod_name' => $category_name . ' - 默认内容',
                'vod_pic' => '',
                'vod_remarks' => $category_name . '分类'
            ];
        }
        
        return ['list' => $list, 'page' => intval($pg), 'pagecount' => 9999, 'limit' => $limit, 'total' => 99999];
    }
    
    public function searchContent($key, $quick = false, $pg = 1) {
        $limit = 40;
        $searchUrl = preg_replace(['/\*\*/', '/\(fypage-1\)/', '/&rn=\d+/'], [urlencode($key), ($pg - 1), '&rn=' . $limit], $this->rule['searchUrl']);
        $resp = $this->fetch($searchUrl, [], $this->headers);
        $json = json_decode(preg_replace('/^callback\((.*?)\)$/', '$1', $resp), true);
        
        $list = [];
        if (isset($json['abslist'])) {
            foreach ($json['abslist'] as $it) {
                $id = 'http://search.kuwo.cn/r.s?stype=albuminfo&user=8d378d72qw28f5f4&uid=2511552006&loginUid=540129516&loginSid=958467960&prod=kwplayer_ar_9.1.8.1&bkprod=kwbook_ar_9.1.8.1&source=kwplayer_ar_9.1.8.1_tvivo.apk&bksource=kwbook_ar_9.1.8.1_tvivo.apk&corp=kuwo&albumid=' . $it['DC_TARGETID'] . '&pn=0&rn=5000&show_copyright_off=1&vipver=MUSIC_8.2.0.0_BCS17&mobi=1&iskwbook=1';
                $list[] = ['vod_id' => $id, 'vod_name' => $it['name'], 'vod_pic' => $it['img'] ?? ''];
            }
        }
        
        return $this->pageResult($list, $pg, 0, $limit);
    }
    
    public function detailContent($ids) {
        $id = is_array($ids) ? $ids[0] : $ids;
        $resp = $this->fetch($id, [], $this->headers);
        $json = json_decode($resp, true);
        
        $list = [];
        if (isset($json['musiclist'])) {
            $urls = [];
            foreach ($json['musiclist'] as $it) {
                $musicUrl = 'http://mobi.kuwo.cn/mobi.s?f=web&source=kwplayerhd_ar_4.3.0.8_tianbao_T1A_qirui.apk&type=convert_url_with_sign&rid=' . $it['musicrid'] . '&br=320kmp3';
                $urls[] = $it['name'] . '$' . $musicUrl;
            }
            
            $list[] = [
                'vod_id' => $id,
                'vod_name' => $json['musiclist'][0]['album'] ?? '未知专辑',
                'vod_pic' => $json['musiclist'][0]['albumpic'] ?? '',
                'vod_play_from' => '酷我听书',
                'vod_play_url' => implode('#', $urls)
            ];
        }
        
        return ['list' => $list];
    }
    
    public function playerContent($flag, $id, $vipFlags = []) {
        $resp = $this->fetch($id, [], $this->headers);
        $json = json_decode($resp, true);
        $url = $json['data']['url'] ?? '';
        return ['parse' => 0, 'url' => $url];
    }
}

(new Spider())->run();