<?php
/**
 * 影视配置动态生成脚本
 * * 职责：
 * 1. 自动扫描子目录并构建 sites 与 lives 数组。
 * 2. 根目录（config.php 所在目录）仅作为扫描起点，其层级下的文件不计入配置。
 * 3. 针对特定的“直播文件”目录应用单层遍历逻辑，忽略其内部的子文件夹。
 * 4. 支持通过 $fileConfig 对站点字段进行动态覆盖。
 * 5. 合并外部 index.json 结构并输出不带转义的 JSON 结果。
 */

header('Content-Type: application/json; charset=utf-8');

// --------------------------------------------------------------------------
// 1. 全局定义
// --------------------------------------------------------------------------

/**
 * 文件类型关联配置
 * 键：后缀名（支持逗号分隔）
 * 值：需覆盖或新增至 site 成员的字段
 */
$fileConfig = [
    'wv.js'   => [
        'api'  => 'csp_WvSpider',
        'jar'  => './lib/WvSpider.jar',
        'type' => 3
    ],
    'txt,m3u' => [
        'api'  => 'csp_FileSpider',
        'jar'  => './lib/WvSpider.jar',
        'type' => 3
    ],
    'php' => [
        'type' => 4,
        'searchable' => 0
    ],
];

// 允许处理的文件后缀
$allowedExtensions = ['js', 'wv.js', 'txt', 'm3u', 'php', 'py'];

// 扫描时跳过的目录名称
$excludeDirs = ['lib', '.', '..'];

// 指定的直播资源根目录名
$liveDirName = '直播文件';

// --------------------------------------------------------------------------
// 2. 扫描引擎
// --------------------------------------------------------------------------

$currentDir = __DIR__;
$sites = [];
$lives = [];

/**
 * 目录递归扫描闭包
 * * @param string $path 当前处理的物理路径
 */
$scanner = function ($path) use (&$scanner, &$sites, &$lives, $currentDir, $fileConfig, $allowedExtensions, $excludeDirs, $liveDirName) {
    $items = scandir($path);
    
    // 解析路径层级关系
    $relativeDirPath = './' . str_replace([$currentDir . DIRECTORY_SEPARATOR, '\\'], ['', '/'], $path);
    $pathParts = explode('/', ltrim($relativeDirPath, './'));
    
    $isRootDir = ($path === $currentDir);
    $isLiveDir = (count($pathParts) === 1 && $pathParts[0] === $liveDirName);

    foreach ($items as $item) {
        if (in_array($item, $excludeDirs)) continue;

        $fullPath = $path . DIRECTORY_SEPARATOR . $item;
        $localPath = './' . str_replace([$currentDir . DIRECTORY_SEPARATOR, '\\'], ['', '/'], $fullPath);

        // 目录成员处理
        if (is_dir($fullPath)) {
            // 直播目录下不再向下探测子目录
            if ($isLiveDir) continue;
            
            // 递归扫描其他子目录
            $scanner($fullPath);
            continue;
        }

        // 文件成员处理
        
        // 根目录层级下的文件不进入配置列表
        if ($isRootDir) continue;

        $extInfo = getFileExtensionInfo($item);
        $ext = $extInfo['full'];

        // 后缀白名单验证
        if (!in_array($ext, $allowedExtensions) && !in_array($extInfo['simple'], $allowedExtensions)) {
            continue;
        }

        // 解析显示名称与目录标签
        $parentDirName = basename($path);
        $tag = preg_match('/\[([^\]]+)\]/', $parentDirName, $m) ? '[' . $m[1] . ']' : '';
        $displayName = preg_replace('/\[([^\]]+)\]/', '', $extInfo['name']);

        if ($isLiveDir) {
            // 直播数据结构构建
            $lives[] = [
                'name'       => $displayName . $tag,
                'type'       => 0,
                'url'        => $localPath,
                'playerType' => 2,
                'epg'        => "http://epg.51zmt.top:8000/api/diyp/?ch={name}&date={date}",
                'logo'       => "https://11.112114.xyz/logo/{$displayName}.png",
                'ua'         => ''
            ];
        } else {
            // 站点数据结构构建
            $sites[] = buildSiteConfig($displayName, $tag, $ext, $localPath, $fileConfig);
        }
    }
};

/**
 * 获取文件名及后缀信息
 * 识别常规后缀与双重后缀（如 .wv.js）
 */
function getFileExtensionInfo($filename) {
    $parts = explode('.', $filename);
    $count = count($parts);
    if ($count >= 3) {
        return [
            'full'   => $parts[$count - 2] . '.' . $parts[$count - 1],
            'simple' => $parts[$count - 1],
            'name'   => implode('.', array_slice($parts, 0, $count - 2))
        ];
    }
    return [
        'full'   => pathinfo($filename, PATHINFO_EXTENSION),
        'simple' => pathinfo($filename, PATHINFO_EXTENSION),
        'name'   => pathinfo($filename, PATHINFO_FILENAME)
    ];
}

/**
 * 构建站点配置对象并应用自定义覆盖逻辑
 */
function buildSiteConfig($name, $tag, $ext, $localPath, $fileConfig) {
    $fullName = $name . $tag . '(' . strtoupper($ext) . ')';
    
    // 默认基础结构
    $config = [
        'key'        => $fullName,
        'name'       => $fullName,
        'type'       => 3,
        'api'        => $localPath,
        'searchable' => 1,
        'filterable' => 1,
        'switchable' => 1
    ];

    // 应用映射配置
    foreach ($fileConfig as $matchExts => $overrides) {
        $extList = array_map('trim', explode(',', $matchExts));
        if (in_array($ext, $extList)) {
            foreach ($overrides as $key => $val) {
                if ($key === 'api' && !empty($val)) {
                    $config['api'] = $val;
                    $config['ext'] = $localPath;
                } else {
                    $config[$key] = $val;
                }
            }
            break;
        }
    }
    return $config;
}

// --------------------------------------------------------------------------
// 3. 配置合并与输出
// --------------------------------------------------------------------------

// 执行递归扫描
$scanner($currentDir);

$finalData = ['sites' => $sites];

// 尝试读取外部 node 配置文件并执行结构合并
$indexJsonPath = realpath($currentDir . '/../drpy-node/index.json');
if ($indexJsonPath && is_file($indexJsonPath)) {
    $content = file_get_contents($indexJsonPath);
    $nodeJson = json_decode($content, true);
    if (is_array($nodeJson)) {
        // 合并 nodeJson 原始字段，并使用新生成的 sites 覆盖
        $nodeJson['sites'] = $sites;
        $finalData = $nodeJson;
    }
}

// 加入直播频道列表
if (!empty($lives)) {
    $finalData['lives'] = $lives;
}

// 输出 JSON 内容，保持中文与斜杠原始状态
echo json_encode(
    $finalData, 
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
);