<script setup lang='ts'>
</script>

<template>
  <div />
</template>

<style>
html,body{
  padding: 20px;
  background-color: beige;
}
</style>
