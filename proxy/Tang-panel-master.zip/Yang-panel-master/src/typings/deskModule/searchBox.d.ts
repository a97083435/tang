declare namespace DeskModule.SearchBox {

    interface SearchEngine  {
        iconSrc: string
        title: string
        url: string
    }

}

