package systemApiStructs

type GetReferralCodeResp struct {
	ReferralCode string `json:"referralCode"`
}
