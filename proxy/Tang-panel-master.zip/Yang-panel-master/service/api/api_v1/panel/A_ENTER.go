package panel

type ApiPanel struct {
	ItemIcon      ItemIcon
	UserConfig    UserConfig
	UsersApi      UsersApi
	ItemIconGroup ItemIconGroup
}
