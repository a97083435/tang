package openness

type ApiPpenness struct {
	Openness Openness
}
