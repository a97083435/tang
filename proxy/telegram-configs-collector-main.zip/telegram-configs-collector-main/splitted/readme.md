# Splitted Configurations
