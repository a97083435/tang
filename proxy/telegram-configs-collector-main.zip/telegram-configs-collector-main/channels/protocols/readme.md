# Splitted Configurations Based On Portocol Types
