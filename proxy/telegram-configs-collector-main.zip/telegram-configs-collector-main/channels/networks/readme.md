# Splitted Configurations Based On Network Types
