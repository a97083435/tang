# Splitted Configurations Based On Security Types
