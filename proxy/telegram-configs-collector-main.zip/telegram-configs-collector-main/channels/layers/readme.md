# Splitted Configurations Based On Internet Protocol Layers
